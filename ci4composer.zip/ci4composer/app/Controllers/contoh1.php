<?php

use CodeIgniter\Controller;

Class Contoh1 extends Controller
{
    public function index()
    {
        echo "<h1>Perkenalkan</h1>";
        echo "Nama saya Rafly
        saya tinggal di jakarta pusat
        olahraga yang saya sukai adalah bulu tangkis";
    }
}
?>